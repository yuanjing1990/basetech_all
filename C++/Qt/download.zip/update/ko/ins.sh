#!/bin/sh

# $1 驱动名 不含.ko 
# $2 设备数量

echo "1 = "$1 
echo "2 = "$2

mode="664"
devCnt=$(expr $2 - 1 )

# 重新装载驱动
/sbin/rmmod $1
/sbin/insmod ./$1.ko || exit 1



major=$(cat /proc/devices | grep "$1"$ | cut -d" " -f1)
#echo $major
echo $1"'s major is "$major

# 删除之前的设备节点
rm -f /dev/$1[0-$devCnt]

# 重新创建设备节点
for i in $(seq 0 $devCnt) 
do 
    echo $(expr $i )
    mknod /dev/$1$i c $major $i
done

exit 0

mknod /dev/${device}0 c $major 0
mknod /dev/${device}1 c $major 1
mknod /dev/${device}2 c $major 2
mknod /dev/${device}3 c $major 3

# give appropriate group/permissions, and change the group.
# Not all distributions have staff, some have "wheel" instead.

group="staff"
grep -q '^staff:' /etc/group || group="wheel"
chgrp $group /dev/${device}[0-3]
chmod $mode /dev/${device}[0-3]
