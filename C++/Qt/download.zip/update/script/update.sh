#/bin/bash

UPDATE_PATH="/media/sda1/update/"
TARGET_PATH="/opt/"

if [ -d ${UPDATE_PATH} ]
then
	cp ${UPDATE_PATH}/* ${TARGET_PATH}/ -arf
	sync
	echo "update success"
	exit 0
else
	echo "update error"
	exit 1
fi

