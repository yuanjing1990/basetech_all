#/bin/bash
#exit 0
#程序路径和名字
PRO_PATH="/opt/ylplt/"
PRO_FILE="ylplt"
PPO_SH_PATH="/opt/script/"
SYS_TMP_PATH="/tmp/"
UPDATE_FILE="update.sh"

#udhcpc -i eth0 &
ifconfig eth0 192.168.1.85 netmask 255.255.255.0 up
route add default gw 192.168.1.1 

#配置QT环境变量
#new qt && tslib env
export QTDIR=/usr/local/Trolltech/QtEmbedded-5.7.0-arm-shared
export TSLIB_DIR=/usr/local/tslib/
export LD_LIBRARY_PATH=/usr/lib:/lib:$QTDIR/lib:$TSLIB_DIR/lib
export TSLIB_TSDEVICE=/dev/input/event0
export TSLIB_FBDEVICE=/dev/fb0
export TSLIB_PLUGINDIR=$TSLIB_DIR/lib/ts
export TSLIB_CONFFILE=$TSLIB_DIR/etc/ts.conf
export POINTERCAL_FILE=$TSLIB_DIR/etc/ts-calib.conf
export QWS_MOUSE_PROTO=tslib:/dev/input/event0
export TSLIB_CONSOLEDEVICE=none
export QT_QPA_PLATFORM_PLUGIN_PATH=$QTDIR/plugin
export QT_QPA_PLATFORM=linuxfb:fb=/dev/fb0
export QT_QPA_GENERIC_PLUGINS=tslib:/dev/input/event0
export TSLIB_TSEVENTTYPE=input
export QT_QPA_FONTDIR=/opt/fonts
export QT_QPA_FB_TSLIB=1
export QT_QPA_EVDEV_TOUCHSCREEN_PARAMETERS=/dev/input/event0
export LANG=zh_CN



 #加载驱动
insmod /opt/ko/gpio.ko

insmod /opt/ko/tps.ko
rm /dev/tps0
mknod /dev/tps0 c 245 0

PRO_REBOOT_CNT=0                                                                                                           

while [ 1 ]                                
do                                         
    #cp ${PPO_SH_PATH}/*.sh ${SYS_TMP_PATH}/                                   
    #chmod +x ${SYS_TMP_PATH}/*.sh                                             
    # 运行程序                     
    cd ${PRO_PATH}
    chmod +x ${PRO_FILE}
    ./${PRO_FILE} 
    let "PRO_REBOOT_CNT=$PRO_REBOOT_CNT+1"
    TMP=0                                 
    let "TMP=$PRO_REBOOT_CNT%5"
    if [ $TMP == "0" ]         
    then                       
        echo "vae"
        # 如果一开始就有卡插上 或者 在上次升级程序失败了的情况下
        # 但是可能存在 系统启动的时候还没有完全识别到USB
        # 所以采用折中的办法 程序多次升级后
        # 重新完全拷贝一次
        # 直接执行升级程序
        chmod +x ${PPO_SH_PATH}/${UPDATE_FILE}
        ${PPO_SH_PATH}/${UPDATE_FILE}
                                                     
    fi                                                                
    sleep 1                                                           
done     
